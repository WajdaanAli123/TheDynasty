const { assert } = require("chai");

assert = chai.assert;

describe('Testing function userscore() of score.js', function (){

it('Tests userscore() with input of 10', function(){
    assert.equal(10, "10/10 Masterpiece");
});

it('Tests userscore() with input of 9', function(){
    assert.equal(9, "9/10 Great");
});

it('Tests userscore() with input of 8', function(){
    assert.equal(8, "8/10 Very Good");
});

it('Tests userscore() with input of 7', function(){
    assert.equal(7, "7/10 Good");
});

it('Tests userscore() with input of 6', function(){
    assert.equal(6, "6/10 Above Anverage");
});

it('Tests userscore() with input of 5', function(){
    assert.equal(5, "5/10 Average");
});

it('Tests userscore() with input of 4', function(){
    assert.equal(4, "4/10 Bad");
});

it('Tests userscore() with input of 3', function(){
    assert.equal(3, "3/10 Very bad");
});

it('Tests userscore() with input of 2', function(){
    assert.equal(2, "2/10 Horrible");
});

it('Tests userscore() with input of 1', function(){
    assert.equal(1, "1/10 Appailling");
});

});