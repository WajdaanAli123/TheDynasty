

$(document).ready(function(){

    $("button").click(function(){
      $("#div1").fadeIn();
      $("#div2").fadeIn("slow");
      $("#div3").fadeIn(2000);
    });

    $(".FF7Rdescription").css({
      color: "black",
      fontSize: "20px"
   });

   $(".EldenRingdescription").css({
      color: "black",
      fontSize: "20px"
   }); 

   $(".Mariodescription").css({
      color: "black",
      fontSize: "20px"
   });

   $(".Kirbydescription").css({
      color: "black",
      fontSize: "20px"
   });
   $(".Zeldadescription").css({
      color: "black",
      fontSize: "20px"
   });
  });




  function userscore(){
    var score= parseInt(prompt("Enter Score;" , " "))
        if(score==10){
            score="10/10 Masterpiece"
        }
            
            
        else if(score==9){
             score="9/10 Amazing"
        }
        
        else if(score==8){
             score="8/10 Really Good"

        }
           
        else if(score==7){
            score="7/10 Good"
        }
          
 
        else if(score==6){
              score="6/10 Above Average"
        }
          
      
        else if (score==5){
             score="5/10 Average"
        }
           

        else if(score==4){
            score="4/10 Bad"
        }
            
        
        else if(score==3){
             score="3/10 Very Bad"
        }
           
       
        else if(score==2){
            score="2/10 Horrible"
        }
            
            
        else if(score==1){
            score="1/10 Appailling"
        }

        else if(score>10||score<0){
            score="Invalid"
        }
        document.getElementById("output").innerHTML=" "+score; 
            
     }
  
     /*About Us*/
     function mouseover(){
        document.getElementById("AboutUs").style.color = "red";
      }
      
      function mouseout(){
        document.getElementById("AboutUs").style.color = "DarkSlateGrey";
      
      }

     
    

     /*FF7R*/
     function FF7Rmouseover(){
        document.getElementById("FF7R").style.color = "red";
     }
     function FF7Rmouseout(){
        document.getElementById("FF7R").style.color = "DarkSlateGrey";
     }
     
     /*EldenRing*/
     function EldenRingmouseover(){
        document.getElementById("EldenRing").style.color = "red";
     }
     function EldenRingmouseout(){
        document.getElementById("EldenRing").style.color = "DarkSlateGrey";
     }

        /*Mario*/
     function Mariomouseover(){
        document.getElementById("Mario").style.color = "red";
     }

     function Mariomouseout(){
        document.getElementById("Mario").style.color = "DarkSlateGrey";
     }

      /*Kirby*/
      function NewlyReleasedBoxmouseover(){
        document.getElementById("Kirby").style.color = "red";
      }
      function NewlyReleasedBoxmouseout(){
        document.getElementById("Kirby").style.color = "DarkSlateGrey";
     }


     /*Zelda*/
     function Totkmouseover(){
        document.getElementById("Totk").style.color = "red";
     }

     function Totkmouseout(){
        document.getElementById("Totk").style.color = "DarkSlateGrey";
     }
      
     function Scoremouseover(){
      document.getElementById("userscore").style.color = "red";
     }

     function Scoremouseout(){
      document.getElementById("userscore").style.color = "Black";
     }

     function Fadedmouseover(){
      document.getElementById("btnsfadedpics").style.color = "red";
     }
      
     function Fadedemouseout(){
      document.getElementById("btnsfadedpics").style.color = "Black";
     }
  